"""
A geared DC actuator, the kind that drives a small robot joint.

Continuous dynamics, integrated with RK4 at a fine step, while the
controller runs at a slower fixed rate. That split matters: a controller
does not see the world continuously, and most of the interesting failures
live in the gap.

State: x = [theta (rad), omega (rad/s)]

    J * omega_dot = Kt * i - b * omega - tau_coulomb * sign(omega) - tau_load
    L * i_dot     = V - R * i - Ke * omega

The electrical time constant is ~1 ms against a mechanical one of ~100 ms,
so the current loop is treated as instantaneous. That assumption is stated
rather than hidden, and the test suite checks it holds for this plant.
"""

from dataclasses import dataclass
import numpy as np


@dataclass
class PlantParams:
    J: float = 0.0025          # kg m^2, reflected inertia at the output
    b: float = 0.012           # N m s, viscous friction
    tau_coulomb: float = 0.015 # N m, dry friction, the nasty nonlinear bit
    Kt: float = 0.22           # N m / A, torque constant
    Ke: float = 0.22           # V s / rad, back EMF
    R: float = 1.6             # ohm
    V_max: float = 24.0        # V, supply limit -> torque saturation
    omega_max: float = 40.0    # rad/s, mechanical limit
    backlash: float = 0.0      # rad, total gear backlash, 0 = none


def torque(V: float, omega: float, p: PlantParams) -> float:
    """Motor torque after the current loop, with supply voltage saturation."""
    V = float(np.clip(V, -p.V_max, p.V_max))
    current = (V - p.Ke * omega) / p.R
    return p.Kt * current


def derivative(x: np.ndarray, V: float, tau_load: float, p: PlantParams) -> np.ndarray:
    theta, omega = x
    tau_m = torque(V, omega, p)

    # Coulomb friction: opposes motion, and holds still things still.
    if abs(omega) < 1e-4:
        tau_f = np.clip(tau_m - tau_load, -p.tau_coulomb, p.tau_coulomb)
    else:
        tau_f = p.tau_coulomb * np.sign(omega)

    omega_dot = (tau_m - p.b * omega - tau_f - tau_load) / p.J
    if (omega >= p.omega_max and omega_dot > 0) or (omega <= -p.omega_max and omega_dot < 0):
        omega_dot = 0.0
    return np.array([omega, omega_dot])


def rk4_step(x: np.ndarray, V: float, tau_load: float, dt: float, p: PlantParams) -> np.ndarray:
    k1 = derivative(x, V, tau_load, p)
    k2 = derivative(x + 0.5 * dt * k1, V, tau_load, p)
    k3 = derivative(x + 0.5 * dt * k2, V, tau_load, p)
    k4 = derivative(x + dt * k3, V, tau_load, p)
    x_next = x + (dt / 6.0) * (k1 + 2 * k2 + 2 * k3 + k4)

    # The limit is enforced in the derivative, but RK4's intermediate
    # stages can still carry the state slightly past it, so clamp the
    # result too. Found by a test asserting omega <= omega_max, which
    # failed at 40.02 rad/s against a 40.0 limit.
    x_next[1] = float(np.clip(x_next[1], -p.omega_max, p.omega_max))
    return x_next
