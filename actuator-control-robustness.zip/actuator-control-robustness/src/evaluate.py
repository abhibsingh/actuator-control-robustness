"""
The actual point of this repo.

Tuning a controller on the nominal plant is easy. The question that
matters on a real machine is what happens when the plant is not the one
you tuned against: the joint carries a heavier payload, friction rises as
it wears, the sensor gets noisier, the control loop picks up latency.

So: tune once, then score the same controller across a grid of perturbed
conditions and report where it degrades and how it fails, not just a
single number on the nominal case.

Run with: python src/evaluate.py
"""

import os
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from plant import PlantParams
from control import PIDGains, LoopConfig, simulate, step_metrics

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
PLOTS, DATA = os.path.join(ROOT, "plots"), os.path.join(ROOT, "data")
os.makedirs(PLOTS, exist_ok=True)
os.makedirs(DATA, exist_ok=True)

STEP = lambda t: 0.0 if t < 0.05 else 1.0   # 1 rad step at 50 ms

# Two controllers: a conservative tune and an aggressive one.
CONTROLLERS = {
    "conservative": PIDGains(kp=25.0, ki=40.0, kd=1.2),
    "aggressive": PIDGains(kp=90.0, ki=260.0, kd=2.6),
}

FAIL_OVERSHOOT_PCT = 25.0
FAIL_SETTLE_S = 1.0
FAIL_SSE_RAD = 0.02


def classify(m):
    """A failure taxonomy beats a pass rate. Which way did it break?"""
    if not m or np.isnan(m.get("rise_time_s", np.nan)):
        return "did_not_reach_target"
    if m["overshoot_pct"] > FAIL_OVERSHOOT_PCT:
        return "overshoot"
    if m["settling_time_s"] > FAIL_SETTLE_S:
        return "slow_to_settle"
    if m["steady_state_error_rad"] > FAIL_SSE_RAD:
        return "steady_state_error"
    return "pass"


def run_case(gains, inertia_scale=1.0, friction_scale=1.0,
             noise=0.0, delay=0, load=0.0):
    p = PlantParams()
    p.J *= inertia_scale
    p.b *= friction_scale
    p.tau_coulomb *= friction_scale
    cfg = LoopConfig(meas_noise_std=noise, meas_delay_steps=delay, load_torque=load)
    r = simulate(STEP, gains, cfg, p)
    m = step_metrics(r["t"], r["theta"], r["setpoint"])
    m["verdict"] = classify(m)
    return r, m


def main():
    report = {"nominal": {}, "sweeps": {}, "summary": {}}

    # ---- nominal
    traces = {}
    for name, g in CONTROLLERS.items():
        r, m = run_case(g)
        report["nominal"][name] = m
        traces[name] = r

    fig, ax = plt.subplots(figsize=(10, 4.5))
    for name, r in traces.items():
        ax.plot(r["t"], r["theta"], lw=1.4, label=name)
    ax.plot(traces["aggressive"]["t"], traces["aggressive"]["setpoint"], "k--", lw=1.0, label="setpoint")
    ax.set_xlabel("time (s)"); ax.set_ylabel("position (rad)")
    ax.set_title("Step response on the nominal plant")
    ax.legend(fontsize=8); ax.grid(alpha=0.3)
    fig.tight_layout(); fig.savefig(os.path.join(PLOTS, "01_nominal.png"), dpi=130); plt.close(fig)

    # ---- sweeps
    grids = {
        "inertia_scale": [0.5, 1.0, 2.0, 4.0, 8.0],
        "friction_scale": [0.5, 1.0, 2.0, 4.0, 8.0],
        "meas_noise_std_rad": [0.0, 0.001, 0.005, 0.01, 0.02],
        "meas_delay_steps": [0, 1, 2, 4, 8],
        "load_torque_Nm": [0.0, 0.02, 0.05, 0.1, 0.2],
    }
    kwarg_for = {
        "inertia_scale": "inertia_scale",
        "friction_scale": "friction_scale",
        "meas_noise_std_rad": "noise",
        "meas_delay_steps": "delay",
        "load_torque_Nm": "load",
    }

    for axis, values in grids.items():
        report["sweeps"][axis] = {}
        for name, g in CONTROLLERS.items():
            rows = []
            for v in values:
                _, m = run_case(g, **{kwarg_for[axis]: v})
                rows.append({"value": v, **m})
            report["sweeps"][axis][name] = rows

    # ---- failure taxonomy across the whole grid
    for name in CONTROLLERS:
        counts = {}
        for axis in grids:
            for row in report["sweeps"][axis][name]:
                counts[row["verdict"]] = counts.get(row["verdict"], 0) + 1
        total = sum(counts.values())
        report["summary"][name] = {
            "cases": total,
            "pass_rate_pct": round(100.0 * counts.get("pass", 0) / total, 1),
            "failure_modes": dict(sorted(counts.items(), key=lambda kv: -kv[1])),
        }

    with open(os.path.join(DATA, "robustness_report.json"), "w") as f:
        json.dump(report, f, indent=2)

    # ---- plot: degradation along two axes that matter most
    fig, axes = plt.subplots(1, 3, figsize=(14, 4.2))
    for ax, axis, ylab in [
        (axes[0], "inertia_scale", "overshoot (%)"),
        (axes[1], "meas_delay_steps", "overshoot (%)"),
        (axes[2], "load_torque_Nm", "steady state error (rad)"),
    ]:
        key = "steady_state_error_rad" if "error" in ylab else "overshoot_pct"
        for name in CONTROLLERS:
            rows = report["sweeps"][axis][name]
            ax.plot([r["value"] for r in rows], [r[key] for r in rows], "o-", label=name)
        ax.set_xlabel(axis); ax.set_ylabel(ylab); ax.grid(alpha=0.3); ax.legend(fontsize=8)
    axes[0].set_title("Heavier payload than tuned for")
    axes[1].set_title("Sensing latency")
    axes[2].set_title("Constant external load")
    fig.tight_layout(); fig.savefig(os.path.join(PLOTS, "02_degradation.png"), dpi=130); plt.close(fig)

    print(json.dumps({"nominal": report["nominal"], "summary": report["summary"]}, indent=2))


if __name__ == "__main__":
    main()
