"""
Controllers and the loop that runs them.

The loop is deliberately realistic in three ways that textbook examples
usually skip:

  1. the controller runs at a fixed rate, slower than the integrator
  2. the measurement can be delayed by a whole number of control steps
  3. the measurement can be noisy, and the derivative term sees that noise
"""

from dataclasses import dataclass
from collections import deque
import numpy as np

from plant import PlantParams, rk4_step


@dataclass
class PIDGains:
    kp: float = 60.0
    ki: float = 120.0
    kd: float = 2.2
    tau_d: float = 0.02      # derivative low pass time constant, seconds
    feedforward: bool = False


@dataclass
class LoopConfig:
    control_hz: float = 200.0
    sim_hz: float = 5000.0
    duration: float = 2.0
    meas_noise_std: float = 0.0     # rad
    meas_delay_steps: int = 0       # in control steps
    load_torque: float = 0.0        # N m, constant external load
    seed: int = 3


class PID:
    def __init__(self, g: PIDGains, dt: float, out_limit: float):
        self.g, self.dt, self.lim = g, dt, out_limit
        self.integral = 0.0
        self.prev_meas = None
        self.d_state = 0.0

    def step(self, setpoint: float, measurement: float) -> float:
        g, dt = self.g, self.dt
        error = setpoint - measurement

        # derivative on measurement, not on error: avoids a kick on step changes
        if self.prev_meas is None:
            raw_d = 0.0
        else:
            raw_d = -(measurement - self.prev_meas) / dt
        self.prev_meas = measurement

        # first order low pass on the derivative term
        alpha = dt / (g.tau_d + dt) if g.tau_d > 0 else 1.0
        self.d_state += alpha * (raw_d - self.d_state)

        unclamped = g.kp * error + g.ki * self.integral + g.kd * self.d_state
        out = float(np.clip(unclamped, -self.lim, self.lim))

        # conditional integration: stop winding up while saturated and
        # the error would push further into the limit
        saturated = out != unclamped
        if not (saturated and np.sign(error) == np.sign(unclamped)):
            self.integral += error * dt

        return out

    def reset(self):
        self.integral = 0.0
        self.prev_meas = None
        self.d_state = 0.0


def simulate(setpoint_fn, gains: PIDGains, cfg: LoopConfig, p: PlantParams):
    """Returns a dict of time series plus the control signal."""
    rng = np.random.default_rng(cfg.seed)
    dt_c = 1.0 / cfg.control_hz
    dt_s = 1.0 / cfg.sim_hz
    steps_per_control = max(1, int(round(dt_c / dt_s)))

    n_control = int(cfg.duration * cfg.control_hz)
    pid = PID(gains, dt_c, out_limit=p.V_max)

    x = np.array([0.0, 0.0])
    delay_buf = deque([0.0] * (cfg.meas_delay_steps + 1), maxlen=cfg.meas_delay_steps + 1)

    t_log, theta_log, sp_log, v_log = [], [], [], []

    for k in range(n_control):
        t = k * dt_c
        sp = setpoint_fn(t)

        measured = x[0] + rng.normal(0.0, cfg.meas_noise_std)
        delay_buf.append(measured)
        delayed = delay_buf[0]

        V = pid.step(sp, delayed)
        if gains.feedforward:
            # static feedforward: the voltage that would hold this velocity
            # at zero error. Here the target is a position, so this term is
            # only useful during the ramp, which is the point of testing it.
            V += p.Ke * np.clip((sp - delayed) * 8.0, -p.omega_max, p.omega_max)
            V = float(np.clip(V, -p.V_max, p.V_max))

        for _ in range(steps_per_control):
            x = rk4_step(x, V, cfg.load_torque, dt_s, p)

        t_log.append(t); theta_log.append(x[0]); sp_log.append(sp); v_log.append(V)

    return {
        "t": np.array(t_log),
        "theta": np.array(theta_log),
        "setpoint": np.array(sp_log),
        "V": np.array(v_log),
    }


# ---------- metrics ----------

def step_metrics(t, y, sp, settle_band=0.02):
    """
    Rise time (10 to 90 percent), overshoot percent, settling time to a
    band around the final setpoint, and steady state error over the last
    10 percent of the run.
    """
    target = sp[-1]
    if abs(target) < 1e-9:
        return {}

    y_norm = y / target
    try:
        i10 = int(np.argmax(y_norm >= 0.1))
        i90 = int(np.argmax(y_norm >= 0.9))
        rise = float(t[i90] - t[i10]) if i90 > i10 else float("nan")
    except ValueError:
        rise = float("nan")

    overshoot = float((np.max(y) - target) / target * 100.0)

    band = settle_band * abs(target)
    outside = np.where(np.abs(y - target) > band)[0]
    settle = float(t[outside[-1]]) if len(outside) else 0.0

    tail = y[int(0.9 * len(y)):]
    sse = float(np.mean(np.abs(tail - target)))

    return {
        "rise_time_s": round(rise, 4),
        "overshoot_pct": round(overshoot, 2),
        "settling_time_s": round(settle, 4),
        "steady_state_error_rad": round(sse, 5),
    }
