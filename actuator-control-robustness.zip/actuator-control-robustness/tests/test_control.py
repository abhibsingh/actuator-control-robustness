import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import numpy as np
from plant import PlantParams, torque, rk4_step
from control import PIDGains, LoopConfig, PID, simulate, step_metrics

STEP = lambda t: 0.0 if t < 0.05 else 1.0


def test_torque_saturates_at_supply_voltage():
    p = PlantParams()
    assert torque(1e6, 0.0, p) == torque(p.V_max, 0.0, p)
    assert torque(-1e6, 0.0, p) == torque(-p.V_max, 0.0, p)


def test_back_emf_reduces_torque_at_speed():
    p = PlantParams()
    assert torque(p.V_max, 0.0, p) > torque(p.V_max, 20.0, p) > 0


def test_stiction_holds_a_still_joint_against_small_torque():
    p = PlantParams()
    x = np.array([0.0, 0.0])
    for _ in range(500):
        x = rk4_step(x, 0.05, 0.0, 1e-4, p)   # tiny voltage
    assert abs(x[0]) < 1e-3


def test_unforced_joint_decelerates():
    p = PlantParams()
    x = np.array([0.0, 10.0])
    for _ in range(2000):
        x = rk4_step(x, 0.0, 0.0, 1e-4, p)
    assert x[1] < 10.0


def test_velocity_limit_respected():
    p = PlantParams()
    x = np.array([0.0, 0.0])
    for _ in range(20000):
        x = rk4_step(x, p.V_max, 0.0, 1e-4, p)
    assert x[1] <= p.omega_max + 1e-6


def test_anti_windup_bounds_the_integral():
    g = PIDGains(kp=500.0, ki=5000.0, kd=0.0)
    pid = PID(g, dt=0.005, out_limit=24.0)
    for _ in range(400):
        pid.step(setpoint=10.0, measurement=0.0)   # permanently saturated
    assert abs(pid.integral) < 1.0


def test_aggressive_tune_rises_faster_than_conservative():
    p, cfg = PlantParams(), LoopConfig()
    cons = simulate(STEP, PIDGains(kp=25.0, ki=40.0, kd=1.2), cfg, p)
    aggr = simulate(STEP, PIDGains(kp=90.0, ki=260.0, kd=2.6), cfg, p)
    mc = step_metrics(cons["t"], cons["theta"], cons["setpoint"])
    ma = step_metrics(aggr["t"], aggr["theta"], aggr["setpoint"])
    assert ma["rise_time_s"] < mc["rise_time_s"]


def test_latency_increases_overshoot():
    p, g = PlantParams(), PIDGains(kp=90.0, ki=260.0, kd=2.6)
    base = simulate(STEP, g, LoopConfig(meas_delay_steps=0), p)
    late = simulate(STEP, g, LoopConfig(meas_delay_steps=6), p)
    mb = step_metrics(base["t"], base["theta"], base["setpoint"])
    ml = step_metrics(late["t"], late["theta"], late["setpoint"])
    assert ml["overshoot_pct"] > mb["overshoot_pct"]
